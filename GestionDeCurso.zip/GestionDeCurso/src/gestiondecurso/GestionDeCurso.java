/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestiondecurso;

/**
 *
 * @author deyve
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GestionDeCurso {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Application::new);
    }
}

class Curso {

    private String nombre;
    private Profesor profesor;
    private ArrayList<Estudiante> estudiantes;
    private Horario horario;

    public Curso(String nombre, Profesor profesor, Horario horario) {
        this.nombre = nombre;
        this.profesor = profesor;
        this.estudiantes = new ArrayList<>();
        this.horario = horario;
    }

    public String mostrarInfo() {
        StringBuilder estudiantesNombres = new StringBuilder();
        for (Estudiante est : estudiantes) {
            estudiantesNombres.append(est.getNombre()).append(" ").append(est.getApellido()).append(", ");
        }
        return String.format("Curso: %s\nProfesor: %s %s\nHorario: %s de %s a %s\nNúmero de estudiantes: %d\nEstudiantes: %s",
                nombre, profesor.getNombre(), profesor.getApellido(), horario.getDia(), horario.getHoraInicio(),
                horario.getHoraFin(), estudiantes.size(), estudiantesNombres.toString());
    }

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }
}

class Profesor {

    private String nombre;
    private String apellido;

    public Profesor(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }
}

class Estudiante {

    private String nombre;
    private String apellido;
    private int idEstudiante;

    public Estudiante(String nombre, String apellido, int idEstudiante) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.idEstudiante = idEstudiante;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }
}

class Horario {

    private String dia;
    private String horaInicio;
    private String horaFin;

    public Horario(String dia, String horaInicio, String horaFin) {
        this.dia = dia;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    public String getDia() {
        return dia;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }
}

 class Application extends JFrame {

    private JTextField nombreCursoField;
    private JTextField nombreProfesorField;
    private JTextField apellidoProfesorField;
    private JTextField diaHorarioField;
    private JTextField horaInicioField;
    private JTextField horaFinField;
    private JTextField numEstudiantesField;
    private JTextArea cursoInfoArea;
    private Curso curso;

    public Application() {
        setTitle("Gestión de Cursos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 2, 5, 5));
        add(panel, BorderLayout.CENTER);

        panel.add(new JLabel("Nombre del Curso:"));
        nombreCursoField = new JTextField();
        panel.add(nombreCursoField);

        panel.add(new JLabel("Nombre del Profesor:"));
        nombreProfesorField = new JTextField();
        panel.add(nombreProfesorField);

        panel.add(new JLabel("Apellido del Profesor:"));
        apellidoProfesorField = new JTextField();
        panel.add(apellidoProfesorField);

        panel.add(new JLabel("Día del Horario:"));
        diaHorarioField = new JTextField();
        panel.add(diaHorarioField);

        panel.add(new JLabel("Hora de Inicio:"));
        horaInicioField = new JTextField();
        panel.add(horaInicioField);

        panel.add(new JLabel("Hora de Fin:"));
        horaFinField = new JTextField();
        panel.add(horaFinField);

        panel.add(new JLabel("Número de Estudiantes:"));
        numEstudiantesField = new JTextField();
        panel.add(numEstudiantesField);

        JButton registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(e -> registrarCurso());
        panel.add(registrarButton);

        cursoInfoArea = new JTextArea();
        cursoInfoArea.setEditable(false);
        add(new JScrollPane(cursoInfoArea), BorderLayout.SOUTH);

        setVisible(true);
    }

    private void registrarCurso() {
        String nombreCurso = nombreCursoField.getText();
        String nombreProfesor = nombreProfesorField.getText();
        String apellidoProfesor = apellidoProfesorField.getText();
        String diaHorario = diaHorarioField.getText();
        String horaInicio = horaInicioField.getText();
        String horaFin = horaFinField.getText();
        String numEstudiantesStr = numEstudiantesField.getText();

        if (!nombreCurso.isEmpty() && !nombreProfesor.isEmpty() && !apellidoProfesor.isEmpty()
                && !diaHorario.isEmpty() && !horaInicio.isEmpty() && !horaFin.isEmpty() && !numEstudiantesStr.isEmpty()) {

            Profesor profesor = new Profesor(nombreProfesor, apellidoProfesor);
            Horario horario = new Horario(diaHorario, horaInicio, horaFin);
            curso = new Curso(nombreCurso, profesor, horario);

            int numEstudiantes = Integer.parseInt(numEstudiantesStr);
            for (int i = 0; i < numEstudiantes; i++) {
                String nombreEstudiante = "Estudiante " + (i + 1);
                String apellidoEstudiante = "Apellido " + (i + 1);
                Estudiante estudiante = new Estudiante(nombreEstudiante, apellidoEstudiante, i + 1);
                curso.agregarEstudiante(estudiante);
            }

            cursoInfoArea.setText(curso.mostrarInfo());
            JOptionPane.showMessageDialog(this, "Curso registrado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
